<?php
include 'funtion.php';
$id = $_GET ["id"];

if(hapus_mapel ($id) >0){
    
    header  ("Location: daftar-mapel.php");
    exit;

   
} 





?>