<?php
$conn = mysqli_connect ('localhost', 'root', '', 'daftar-mapel');

function tambah_mapel ($cari) {
    global $conn;
    $hari =  htmlspecialchars($_POST["hari"]);
    $jam_ke =  htmlspecialchars($_POST["jam_ke"]);
    $waktu =  htmlspecialchars($_POST["waktu"]);
    $kelas =  htmlspecialchars($_POST["kelas"]);
    $pelajaran =  htmlspecialchars($_POST["pelajaran"]);
    $kode_guru =  htmlspecialchars($_POST["kode_guru"]);
    
    $cari="INSERT INTO mapel
    VALUES ('','$hari', '$jam_ke' , '$waktu' , '$kelas', '$pelajaran' , '$kode_guru' )
    ";
    mysqli_query ($conn, $cari);

    return mysqli_affected_rows ($conn); }

function edit_mapel ($cari) {
    global $conn;
    $id =  htmlspecialchars($_POST["id"]);
    $hari =  htmlspecialchars($_POST["hari"]);
    $jam_ke =  htmlspecialchars($_POST["jam_ke"]);
    $waktu =  htmlspecialchars($_POST["waktu"]);
    $kelas =  htmlspecialchars($_POST["kelas"]);
    $pelajaran =  htmlspecialchars($_POST["pelajaran"]);
    $kode_guru =  htmlspecialchars($_POST["kode_guru"]);

    //$query= "INSERT INTO barang VALUES ('','$stok_barang',  '$gambar', '$judul', '$penerbit')";
    $cari="UPDATE mapel SET
            id ='$id',
            hari ='$hari',
            jam_ke='$jam_ke',
            waktu ='$waktu',
            kelas='$kelas',
            pelajaran ='$pelajaran',
            kode_guru ='$kode_guru'
            WHERE id=$id";
mysqli_query ($conn, $cari);
return mysqli_affected_rows ($conn);
}

function hapus_mapel ($id){
    global $conn;
    mysqli_query ($conn, "DELETE FROM mapel WHERE id = $id");
    return mysqli_affected_rows ($conn);

}

?>