<?php
include 'funtion.php';

if(isset($_POST["cari"])) {
   $pencarian=$_POST ["pencarian"];
   $cari_dm= "SELECT*FROM mapel
    WHERE
    id like'%$pencarian%' or
    hari like'%$pencarian%' or
    jam_ke like'%$pencarian%' or
    waktu like'%$pencarian%' or
    kelas like'%$pencarian%' or
    pelajaran like'%$pencarian%' or
    kode_guru like'%$pencarian%'
    ";
    $cari=mysqli_query($conn, $cari_dm);
}else{
    $cari=mysqli_query($conn,"SELECT*FROM mapel");

}
?>
<!doctype html>
<html>
    <head><title>Aplikasi Daftar Mata Pelajaran PPLG UKK SMKN 6 Kota Jambi</title>
          <link rel="stylesheet" type="text/css" href="style.css">
        </head>
    <body>
          <div class="header">
          <div class="header-logo">
          <img src="logosmkn6.jpg" alt="Gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">Aplikasi Daftar Mata Pelajaran PPLG UKK SMKN 6 Kota Jambi</a>
          </div>
          </div>
          <ul class="menu">
              <li class="menu-item"><a href="index.php">Beranda</a></li>
              <li class="menu-item"><a href="daftar-mapel.php">Daftar Mapel</a></li>
              <li class="menu-item"><a href="tambah-mapel.php">Tambah Mapel</a></li>
             
          </ul>
          <div class="konten">
             <h1>Daftar Mata Pelajaran PPLG</h1>
             <a href="tambah-mapel.php">Tambah Mata Pelajaran</a>
             <br>
             <form action="" method="post">
             <br>
             <input type="text" name="pencarian" placeholder="Ketik Pencarian Anda" autofocus autocomplete="off" size=""50px>
            </br>
             <button type="submit" name="cari">Cari Mapel</button>
</form>
              <table class="tabel">
                <tr class="tabel-header">
                    <th>Hari</th>
                    <th>Jam Ke</th>
                    <th>Waktu</th>
                    <th>Kelas</th>
                    <th>Pelajaran</th>
                    <th>Kode Guru</th>
                    <th>Seting</th>
                </tr>
                <?php 
                $nomor=1;
                ?>
            <?php while($data=mysqli_fetch_assoc($cari)):
            ?>

                <tr class="tabel-konten">
                    <td><?php echo $data ["hari"];?></td>
                    <td><?php echo $data ["jam_ke"];?></td>
                    <td><?php echo $data ["waktu"];?></td>
                    <td><?php echo $data ["kelas"];?></td>
                    <td><?php echo $data ["pelajaran"];?></td>
                    <td><?php echo $data ["kode_guru"];?></td>
                    
                    <td>
                        <a href="edit.php?id=<?=  $data ["id"]; ?> ">Edit</a> |
                        <a href="hapus.php?id=<?=  $data ["id"]; ?> "onclick = "return confirm ('Apakah anda yakin?')">Hapus</a>
                    </td>
                </tr>
                <?php
                $nomor ++;
                ?>
                <?php
                endwhile;
                ?>
</table>
          </div>
          <div class="fotter">
            <p>KEYZIA LAURA ANANDITA XII PPLG 1(PPLG01-0027)
            </p>
          </div>
    </body>
</html>