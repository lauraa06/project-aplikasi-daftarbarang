<!DOCTYPE html>
<html>
    <head><title>Aplikasi Daftar Mata Pelajaran UKK SMKN 6 Kota Jambi</title>
          <link rel="stylesheet" type="text/css" href="style.css">
        </head>
    <body>
          <div class="header">
             <div class="header-logo">
             <img src="logosmkn6.jpg" alt="ini gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">Aplikasi Daftar Mata Pelajaran UKK SMKN 6 Kota Jambi</a>
          </div>
          </div>
          <ul class="menu">
          <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="daftar-mapel.php">Daftar Mapel</a></li>
        <li class="menu-item"><a href="tambah-mapel.php">Tambah Mapel</a></li>
          </ul>
          <div class="konten">
            <h1>Project Aplikasi</h1>
            <h2>Daftar Mata Pelajaran UKK SMKN 6 Kota Jambi </h2>
          </div>
          <div class="fotter">
            <p>KEYZIA LAURA ANANDITA XII PPLG 1(PPLG01-0027)</p>
          </div>
    </body>
</html>