<?php
include 'funtion.php';


if(isset($_POST["cari"])) {
   $pencarian=$_POST ["pencarian"];
   $cari_db= "SELECT*FROM barang
    WHERE
    kode_barang like'%$pencarian%' or
    nama_barang like'%$pencarian%' or
    stok_barang like'%$pencarian%' or
    harga like'%$pencarian%'
    ";
    $cari=mysqli_query($conn, $cari_db);
}else{
    $cari=mysqli_query($conn,"SELECT*FROM barang");

}
?>
<!doctype html>
<html>
    <head><title>Aplikasi Daftar Barang UKK SMKN 6 Kota Jambi</title>
          <link rel="stylesheet" type="text/css" href="style.css">
        </head>
    <body>
          <div class="header">
          <div class="header-logo">
          <img src="logosmkn6.jpg" alt="Gambar logo">
          </div>
          <div class="header-title">
              <a href="index.php">Aplikasi Daftar Barang UKK SMKN 6 Kota Jambi</a>
          </div>
          </div>
          <ul class="menu">
              <li class="menu-item"><a href="index.php">Beranda</a></li>
              <li class="menu-item"><a href="daftar-barang.php">Daftar Barang</a></li>
              <li class="menu-item"><a href="tambah-barang.php">Tambah Barang</a></li>
             
          </ul>
          <div class="konten">
             <h1>Daftar Barang Toko Kita</h1>
             <a href="tambah-barang.php">Tambah Barang</a>
             <br>
             <form action="" method="post">
             <br>
             <input type="text" name="pencarian" placeholder="Ketik Pencarian Anda" autofocus autocomplete="off" size=""50px>
            </br>
             <button type="submit" name="cari">Cari Barang</button>
</form>
              <table class="tabel">
                <tr class="tabel-header">
                    <th>No</th>
                    <th>Kode Barang</th>
                    <th>Nama Barang</th>
                    <th>Stok Barang</th>
                    <th>Harga</th>
                    <th>Seting</th>
                </tr>
                <?php 
                $nomor=1;
                ?>
            <?php while($data=mysqli_fetch_assoc($cari)):
            ?>

                <tr class="tabel-konten">
                    <td><?php echo $nomor; ?></td>
                    <td><?php echo $data ["kode_barang"];?></td>
                    <td><?php echo $data ["nama_barang"];?></td>
                    <td><?php echo $data ["stok_barang"];?></td>
                    <td><?php echo $data ["harga"];?></td>
                    
                    <td>
                        <a href="edit.php?kode_barang=<?=  $data ["kode_barang"]; ?> ">Edit</a> |
                        <a href="hapus.php?kode_barang=<?=  $data ["kode_barang"]; ?> "onclick = "return confirm ('Apakah anda yakin?')">Hapus</a>
                    </td>
                </tr>
                <?php
                $nomor ++;
                ?>
                <?php
                endwhile;
                ?>
</table>
          </div>
          <div class="fotter">
            <p>KEYZIA LAURA ANANDITA XII PPLG 1(PPLG01-0027)</p>
          </div>
    </body>
</html>