<?php
include 'funtion.php';

//Cek apakah $_post submit sudah di tekan atau belum
if(isset($_POST["submit"])){
//var_dump($_POST); //ada tidak data yang ada di $_POST nya
//ambil data dari tiap element dalam form

         if(tambah_barang ($_POST) >0){
           
                echo "<script>
                alert ('Data Berhasil ditambahkan');
                document.location.href='daftar-barang.php';
                </script>
                ";
                
            } else {
                echo "<script>
                alert ('Data Gagal ditambahkan');
                document.location.href='daftar-barang.php';
                </script>
                ";   
                
            }
    

         }
       
       

        //Query Insert Data
       
        
        //untuk mengecek apakah data brhasil di tambahkan atau tidak
        var_dump(mysqli_affected_rows($conn));
       
        

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang</title><link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
        <div class="header-logo">
            <img src="logosmkn6.jpg" alt="Gambar Logo" >
        </div>
        <div class="header-title">
            <a href="index.php"> Aplikasi Daftar Barang & Daftar Pelajaran UKK SMKN 6 Kota Jambi</a>
        </div>
    </div>
	<ul class="menu">
        <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="daftar-barang.php">Daftar Barang</a></li>
        <li class="menu-item"><a href="tambah-barang.php">Tambah Barang</a></li>
      
    </ul>
    <h1>Daftar Barang</h1>
    <h2>Tambah Barang</h2>
    <form action="" method="post">
    <label for="">Kode Barang</label>
        <input type="text" name="kode_barang" id="kode_barang" required>
        <br>
        <label for="">Nama Barang</label>
        <input type="text" name="nama_barang" id="nama_barang" required>
        <br>
        <label for="">Stok Barang</label>
        <input type="text" name="stok_barang" id="stok_barang" required>
        <br>
        <label for="">Harga</label>
        <input type="text"  name="harga" id="harga"  required>
        <br>
        <button type="submit" name="submit">Tambahkan Data</button>

    </form>
    <div class="fotter">
        <P>KEYZIA LAURA ANANDITA XII PPLG 1</P> 
 
     </div>    
</body>
</html>