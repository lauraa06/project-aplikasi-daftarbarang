<?php
$conn = mysqli_connect ('localhost', 'root', '', 'daftar-barang');

function tambah_barang ($cari) {
    global $conn;
    $kode_barang =  htmlspecialchars($_POST["kode_barang"]);
    $nama_barang =  htmlspecialchars($_POST["nama_barang"]);
    $stok_barang =  htmlspecialchars($_POST["stok_barang"]);
    $harga =  htmlspecialchars($_POST["harga"]);
    
    $cari="INSERT INTO barang
    VALUES ('','$kode_barang', '$nama_barang' , '$stok_barang' , '$harga' )
    ";
    mysqli_query ($conn,$cari);

    return mysqli_affected_rows ($conn);
}

function edit_barang ($cari) {
    global $conn;
    $kode_barang=htmlspecialchars ($_POST ["kode_barang"]);
    $nama_barang =htmlspecialchars ($_POST ["nama_barang"]);
    $stok_barang=htmlspecialchars ($_POST ["stok_barang"]);
    $harga =htmlspecialchars ($_POST ["harga"]);

    //$query= "INSERT INTO barang VALUES ('','$stok_barang',  '$gambar', '$judul', '$penerbit')";
    $cari="UPDATE barang SET
            kode_barang ='$kode_barang',
            nama_barang='$nama_barang',
            stok_barang ='$stok_barang',
            harga='$harga'
            WHERE kode_barang=$kode_barang";
mysqli_query ($conn, $cari);
return mysqli_affected_rows ($conn);
}

function hapus_barang ($kode_barang){
    global $conn;
    mysqli_query ($conn, "DELETE FROM barang WHERE kode_barang = $kode_barang");
    return mysqli_affected_rows ($conn);


}

?>