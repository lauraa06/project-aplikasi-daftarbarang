<?php
include 'funtion.php';
$kode_barang = $_GET ["kode_barang"];
$cari = mysqli_query ($conn, "SELECT*FROM barang WHERE kode_barang= $kode_barang");
if (isset ($_POST ["submit"])){
   
    // var_dump($_POST);
   

//var_dump(mysqli_affected_rows ($conn));
if(edit_barang ($_POST) >0){
           
    echo "<script>
    alert ('Data Berhasil diedit');
    document.location.href='daftar-barang.php';
    </script>
    ";
    
} else {
    echo "<script>
    alert ('Data Gagal dihapus');
    document.location.href='daftar-barang.php';
    </script>
    ";   
    
}



}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang</title><link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
<div class="header-logo">
<img src="logosmkn6.jpg" alt="Gambar logo">
        </div>
        <div class="header-title">
            <a href="index.php"> Perpusakaan SMKN 6 Kota Jambi</a>
        </div>
    </div>
	<ul class="menu">
        <li class="menu-item"><a href="index.php">Beranda</a> </li>
        <li class="menu-item"><a href="daftar-barang.php">Daftar Barang</a></li>
        <li class="menu-item"><a href="tambah-barang.php">Tambah Barang</a></li>
      
    </ul>
    <div class="konten">
       <h1>Edit barang</h1>
       <?php
       while($data=mysqli_fetch_assoc ($cari)):
       ?>
       <form action=""method="POST">
       <input type="text"name="kode_barang" VALUE="<?php echo $data ["kode_barang"]; ?>">
       <label for=""> nama barang</label>
       <input type="text"name="nama_barang" id= required VALUE="<?php echo $data ["nama_barang"]; ?>">
       <br>
       <label for=""> stok barang</label>
       <input type="text"name="stok_barang" id= required VALUE="<?php echo $data ["stok_barang"]; ?>">
       <br>
       <label for="">harga</label>
       <input type="text"name="harga" id= required VALUE="<?php echo $data ["harga"]; ?>">
       <br>
       <button type="submit" name="submit">kirim edit data</button>
       </form>
       <?php
       endwhile;
       ?>
       </div>

       <div class="fotter">
            <p>KEYZIA LAURA ANANDITA XII PPLG 1(PPLG01-0027)</p>
        </div>

</body>
</html>