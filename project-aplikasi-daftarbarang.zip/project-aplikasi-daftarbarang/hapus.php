<?php
include 'funtion.php';
$kode_barang = $_GET ["kode_barang"];

if(hapus_barang ($kode_barang) >0){
    
    header  ("Location: daftar-barang.php");
    exit;

   
} 





?>